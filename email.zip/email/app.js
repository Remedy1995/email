const express=require('express');
const bodyparser=require('body-parser');
const app=express();
const https=require('https');
app.use(bodyparser.urlencoded({extended:true}));


app.get('/',function(req,res){
    res.sendFile(__dirname + "/index.html");
})




app.post('/',function(req,res){
    const fname=req.body.first;
 const lname = req.body.last;
    const  email =req.body.email;


const  data={
    members:[
        {
           email_address:email, 
            status:"subscribed",
            merge_fields:{
                FNAME:fname,
                LNAME:lname
            }
        }
    ]
};
  const jsonData=JSON.stringify(data);


    const url = "https://us10.api.mailchimp.com/3.0/lists/9af916c604"

const options={
    method:"POST",
    auth:"remedy:deae95a2ab67681ade058e7b417a3d04-us10"
}

const request= https.request(url,options,function(response){

    if(response.statusCode===200){
res.sendFile(__dirname+"/success.html");
    
}else{
    res.sendFile(__dirname+"/failure.html");
}
response.on("data",function(data){
console.log(JSON.parse(data));
})
})
request.write(jsonData);
request.end(); 
});

app.post('/failure', function (req, res) {
    res.redirect("/");
})


app.post('/success', function (req, res) {
    res.redirect("/");
})


app.listen(7000,function(){
    console.log("you are running the app on port 7000");
}


)

//
//9af916c604